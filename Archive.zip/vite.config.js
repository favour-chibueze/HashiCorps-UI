 server: {
    host: true
  }